(function(){function T(t){if(t.id&&/^[a-zA-Z][\w-]*$/.test(t.id)){const i=`#${t.id}`;try{if(document.querySelector(i)===t)return i}catch{}}const e=t.tagName.toLowerCase(),n=Array.from(t.classList).filter(i=>/^[a-zA-Z][\w-]*$/.test(i)).slice(0,3).join(".");if(n){const i=`${e}.${n}`;try{if(document.querySelector(i)===t)return i}catch{}}return I(t,5)}function I(t,e){const n=[];let i=t,s=0;for(;i&&i!==document.documentElement&&s<e;){const w=i.tagName.toLowerCase(),f=i.parentElement;if(!f)break;const x=Array.from(f.children).filter(h=>h.tagName===i.tagName);if(x.length>1){const h=x.indexOf(i)+1;n.unshift(`${w}:nth-of-type(${h})`)}else n.unshift(w);i=f,s++}return n.join(" > ")||tag}const d="__guidesnap_overlay_host__";let a=null,u=null,p=null,c=null;const O=`
  :host { all: initial; }
  #gs-bar {
    position: fixed !important;
    bottom: 24px !important;
    right: 24px !important;
    z-index: 2147483647 !important;
    background: #1e1e2e !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 12px 16px !important;
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    font-size: 13px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,.35) !important;
    min-width: 200px !important;
    user-select: none !important;
  }
  #gs-dot {
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background: #ef4444 !important;
    flex-shrink: 0 !important;
    animation: gs-pulse 1.2s ease-in-out infinite !important;
  }
  #gs-dot.paused {
    background: #f59e0b !important;
    animation: none !important;
  }
  @keyframes gs-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
  }
  #gs-info { flex: 1 !important; }
  #gs-state { font-size: 11px !important; color: #FF6B35 !important; font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: .5px !important; }
  #gs-steps { font-size: 13px !important; color: #e0e0e0 !important; margin-top: 2px !important; }
  #gs-actions { display: flex !important; gap: 6px !important; }
  button {
    border: none !important;
    border-radius: 6px !important;
    padding: 5px 10px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: opacity .15s !important;
  }
  button:hover { opacity: .8 !important; }
  #gs-pause { background: rgba(255,255,255,.12) !important; color: #fff !important; }
  #gs-stop { background: #ef4444 !important; color: #fff !important; }
`;function v(){if(document.getElementById(d))return;const t=document.createElement("div");t.id=d,a=t.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=O,a.appendChild(e);const n=document.createElement("div");n.id="gs-bar",n.innerHTML=`
    <div id="gs-dot"></div>
    <div id="gs-info">
      <div id="gs-state">Recording</div>
      <div id="gs-steps">Step 0</div>
    </div>
    <div id="gs-actions">
      <button id="gs-pause">Pause</button>
      <button id="gs-stop">Stop</button>
    </div>
  `,a.appendChild(n),c=a.getElementById("gs-dot"),u=a.getElementById("gs-steps"),p=a.getElementById("gs-state"),a.getElementById("gs-pause").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"PAUSE_RECORDING"})}),a.getElementById("gs-stop").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"STOP_RECORDING"})}),document.documentElement.appendChild(t)}function E(t,e){a&&(u&&(u.textContent=`${t} step${t!==1?"s":""} captured`),p&&(p.textContent=e==="paused"?"Paused":"Recording"),c&&(e==="paused"?c.classList.add("paused"):c.classList.remove("paused")))}function R(){const t=document.getElementById(d);t&&t.remove(),a=null,u=null,p=null,c=null}function B(){const t=document.getElementById(d);t&&(t.style.visibility="hidden")}function A(){const t=document.getElementById(d);t&&(t.style.visibility="visible")}if(window.__guidesnap_initialized__)throw new Error("GuideSnap content script already initialized");window.__guidesnap_initialized__=!0;let r=!1,o=!1,y=null,b=window.scrollY;const P=300,l=window.devicePixelRatio||1;console.log("[GuideSnap] Content script initialized");chrome.runtime.sendMessage({type:"GET_STATE"},t=>{console.log("[GuideSnap] Initial state:",t),(t==null?void 0:t.state)==="recording"?(r=!0,o=!1,v(),E(t.stepCount,"recording"),k()):(t==null?void 0:t.state)==="paused"&&(r=!0,o=!0,v(),E(t.stepCount,"paused"))});chrome.runtime.onMessage.addListener((t,e,n)=>{if(console.log("[GuideSnap] Content script received message:",t),t.type==="UPDATE_OVERLAY"){const{stepCount:i,state:s}=t.payload;if(s==="idle"){r=!1,o=!1,Y(),R();return}s==="recording"&&!r?(console.log("[GuideSnap] Starting recording, attaching listeners"),r=!0,o=!1,v(),k()):s==="paused"?o=!0:s==="recording"&&o&&(o=!1),E(i,s),n({ok:!0})}if(t.type==="HIDE_OVERLAY"){B(),n({ok:!0});return}return t.type==="SHOW_OVERLAY"&&(A(),n({ok:!0})),!0});function S(t){var n;const e=t.getBoundingClientRect();return{tag:t.tagName.toLowerCase(),text:((n=t.innerText)==null?void 0:n.trim().substring(0,80))??"",cssSelector:T(t),boundingBox:{x:e.left*l,y:e.top*l,width:e.width*l,height:e.height*l}}}function g(t){chrome.runtime.sendMessage({type:"USER_EVENT",payload:t}).catch(()=>{})}const z=new Set(["a","button","input","select","textarea","label","li","summary","details","option"]),G=5;function M(t){let e=t;for(let n=0;n<G&&e;n++){if(z.has(e.tagName.toLowerCase()))return e;e=e.parentElement}return t}function _(t){if(console.log("[GuideSnap] Click detected, isRecording:",r,"isPaused:",o),!r||o)return;const e=t.target;if(!e||N(e))return;const n=M(e),i={eventType:"click",element:S(n),clickPoint:{x:t.clientX*l,y:t.clientY*l},pageTitle:document.title,pageUrl:location.href};console.log("[GuideSnap] Sending click event:",i),g(i)}function L(t){if(!r||o)return;const e=t.target;if(!e||e.type==="password")return;const n={eventType:"input",element:S(e),clickPoint:null,inputValue:e.value.substring(0,80),pageTitle:document.title,pageUrl:location.href};g(n)}function m(){if(!r||o)return;const t={eventType:"navigate",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};g(t)}function C(){!r||o||Math.abs(window.scrollY-b)<P||(b=window.scrollY,y&&clearTimeout(y),y=setTimeout(()=>{const e={eventType:"scroll",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};g(e)},500))}function N(t){return t.closest("#__guidesnap_overlay_host__")!==null}function k(){document.addEventListener("click",_,!0),document.addEventListener("change",L,!0),window.addEventListener("popstate",m),window.addEventListener("hashchange",m),window.addEventListener("scroll",C,{passive:!0})}function Y(){document.removeEventListener("click",_,!0),document.removeEventListener("change",L,!0),window.removeEventListener("popstate",m),window.removeEventListener("hashchange",m),window.removeEventListener("scroll",C)}
})()

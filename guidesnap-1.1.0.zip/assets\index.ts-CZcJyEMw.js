(function(){function N(t){if(t.id&&/^[a-zA-Z][\w-]*$/.test(t.id)){const i=`#${t.id}`;try{if(document.querySelector(i)===t)return i}catch{}}const e=t.tagName.toLowerCase(),n=Array.from(t.classList).filter(i=>/^[a-zA-Z][\w-]*$/.test(i)).slice(0,3).join(".");if(n){const i=`${e}.${n}`;try{if(document.querySelector(i)===t)return i}catch{}}return z(t,5)}function z(t,e){const n=[];let i=t,r=0;for(;i&&i!==document.documentElement&&r<e;){const g=i.tagName.toLowerCase(),u=i.parentElement;if(!u)break;const f=Array.from(u.children).filter(l=>l.tagName===i.tagName);if(f.length>1){const l=f.indexOf(i)+1;n.unshift(`${g}:nth-of-type(${l})`)}else n.unshift(g);i=u,r++}return n.join(" > ")||tag}const m="__guidesnap_overlay_host__";let a=null,h=null,v=null,p=null;const G=`
  :host { all: initial; }
  #gs-bar {
    position: fixed !important;
    bottom: 24px !important;
    right: 24px !important;
    z-index: 2147483647 !important;
    background: #1e1e2e !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 12px 16px !important;
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    font-size: 13px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,.35) !important;
    min-width: 200px !important;
    user-select: none !important;
  }
  #gs-dot {
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background: #ef4444 !important;
    flex-shrink: 0 !important;
    animation: gs-pulse 1.2s ease-in-out infinite !important;
  }
  #gs-dot.paused {
    background: #f59e0b !important;
    animation: none !important;
  }
  @keyframes gs-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
  }
  #gs-info { flex: 1 !important; }
  #gs-state { font-size: 11px !important; color: #FF6B35 !important; font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: .5px !important; }
  #gs-steps { font-size: 13px !important; color: #e0e0e0 !important; margin-top: 2px !important; }
  #gs-actions { display: flex !important; gap: 6px !important; }
  button {
    border: none !important;
    border-radius: 6px !important;
    padding: 5px 10px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: opacity .15s !important;
  }
  button:hover { opacity: .8 !important; }
  #gs-pause { background: rgba(255,255,255,.12) !important; color: #fff !important; }
  #gs-stop { background: #ef4444 !important; color: #fff !important; }
`;function b(){if(document.getElementById(m))return;const t=document.createElement("div");t.id=m,a=t.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=G,a.appendChild(e);const n=document.createElement("div");n.id="gs-bar",n.innerHTML=`
    <div id="gs-dot"></div>
    <div id="gs-info">
      <div id="gs-state">Recording</div>
      <div id="gs-steps">Step 0</div>
    </div>
    <div id="gs-actions">
      <button id="gs-pause">Pause</button>
      <button id="gs-stop">Stop</button>
    </div>
  `,a.appendChild(n),p=a.getElementById("gs-dot"),h=a.getElementById("gs-steps"),v=a.getElementById("gs-state"),a.getElementById("gs-pause").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"PAUSE_RECORDING"})}),a.getElementById("gs-stop").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"STOP_RECORDING"})}),document.documentElement.appendChild(t)}function x(t,e){a&&(h&&(h.textContent=`${t} step${t!==1?"s":""} captured`),v&&(v.textContent=e==="paused"?"Paused":"Recording"),p&&(e==="paused"?p.classList.add("paused"):p.classList.remove("paused")))}function M(){const t=document.getElementById(m);t&&t.remove(),a=null,h=null,v=null,p=null}function $(){const t=document.getElementById(m);t&&(t.style.visibility="hidden")}function Y(){const t=document.getElementById(m);t&&(t.style.visibility="visible")}if(window.__guidesnap_initialized__)throw new Error("GuideSnap content script already initialized");window.__guidesnap_initialized__=!0;let s=!1,o=!1,w=null,A=window.scrollY;const U=300,d=window.devicePixelRatio||1;console.log("[GuideSnap] Content script initialized");chrome.runtime.sendMessage({type:"GET_STATE"},t=>{console.log("[GuideSnap] Initial state:",t),(t==null?void 0:t.state)==="recording"?(s=!0,o=!1,b(),x(t.stepCount,"recording"),P()):(t==null?void 0:t.state)==="paused"&&(s=!0,o=!0,b(),x(t.stepCount,"paused"))});chrome.runtime.onMessage.addListener((t,e,n)=>{if(console.log("[GuideSnap] Content script received message:",t),t.type==="UPDATE_OVERLAY"){const{stepCount:i,state:r}=t.payload;if(r==="idle"){s=!1,o=!1,F(),M();return}r==="recording"&&!s?(console.log("[GuideSnap] Starting recording, attaching listeners"),s=!0,o=!1,b(),P()):r==="paused"?o=!0:r==="recording"&&o&&(o=!1),x(i,r),n({ok:!0})}if(t.type==="HIDE_OVERLAY"){$(),n({ok:!0});return}return t.type==="SHOW_OVERLAY"&&(Y(),n({ok:!0})),!0});function I(t){var S,_,L,C,T;const e=t.getBoundingClientRect(),n=t.tagName.toLowerCase(),i=((S=t.getAttribute("aria-label"))==null?void 0:S.trim())||void 0,r=((_=t.getAttribute("placeholder"))==null?void 0:_.trim())||void 0,g=((L=t.getAttribute("name"))==null?void 0:L.trim())||void 0,u=((C=t.getAttribute("title"))==null?void 0:C.trim())||void 0,f=n==="input"&&t.type||void 0;let l;if(t.id){const c=document.querySelector(`label[for="${CSS.escape(t.id)}"]`);c&&(l=c.innerText.trim()||void 0)}if(!l){let c=t.parentElement;for(let k=0;k<3&&c;k++,c=c.parentElement)if(c.tagName.toLowerCase()==="label"){l=c.innerText.trim()||void 0;break}}return{tag:n,text:((T=t.innerText)==null?void 0:T.trim().substring(0,80))??"",cssSelector:N(t),boundingBox:{x:e.left*d,y:e.top*d,width:e.width*d,height:e.height*d},ariaLabel:i,placeholder:r,name:g,inputType:f,title:u,labelText:l}}function E(t){chrome.runtime.sendMessage({type:"USER_EVENT",payload:t}).catch(()=>{})}const D=new Set(["a","button","input","select","textarea","label","li","summary","details","option"]),H=5;function V(t){let e=t;for(let n=0;n<H&&e;n++){if(D.has(e.tagName.toLowerCase())||e.hasAttribute("placeholder"))return e;e=e.parentElement}return t}function O(t){if(console.log("[GuideSnap] Click detected, isRecording:",s,"isPaused:",o),!s||o)return;const e=t.target;if(!e||q(e))return;const n=V(e),i={eventType:"click",element:I(n),clickPoint:{x:t.clientX*d,y:t.clientY*d},pageTitle:document.title,pageUrl:location.href};console.log("[GuideSnap] Sending click event:",i),E(i)}function R(t){if(!s||o)return;const e=t.target;if(!e||e.type==="password")return;const n={eventType:"input",element:I(e),clickPoint:null,inputValue:e.value.substring(0,80),pageTitle:document.title,pageUrl:location.href};E(n)}function y(){if(!s||o)return;const t={eventType:"navigate",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};E(t)}function B(){!s||o||Math.abs(window.scrollY-A)<U||(A=window.scrollY,w&&clearTimeout(w),w=setTimeout(()=>{const e={eventType:"scroll",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};E(e)},500))}function q(t){return t.closest("#__guidesnap_overlay_host__")!==null}function P(){document.addEventListener("click",O,!0),document.addEventListener("change",R,!0),window.addEventListener("popstate",y),window.addEventListener("hashchange",y),window.addEventListener("scroll",B,{passive:!0})}function F(){document.removeEventListener("click",O,!0),document.removeEventListener("change",R,!0),window.removeEventListener("popstate",y),window.removeEventListener("hashchange",y),window.removeEventListener("scroll",B)}
})()

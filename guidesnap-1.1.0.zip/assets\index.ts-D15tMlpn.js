(function(){function $(t){if(t.id&&/^[a-zA-Z][\w-]*$/.test(t.id)){const i=`#${t.id}`;try{if(document.querySelector(i)===t)return i}catch{}}const e=t.tagName.toLowerCase(),n=Array.from(t.classList).filter(i=>/^[a-zA-Z][\w-]*$/.test(i)).slice(0,3).join(".");if(n){const i=`${e}.${n}`;try{if(document.querySelector(i)===t)return i}catch{}}return Y(t,5)}function Y(t,e){const n=[];let i=t,r=0;for(;i&&i!==document.documentElement&&r<e;){const v=i.tagName.toLowerCase(),m=i.parentElement;if(!m)break;const y=Array.from(m.children).filter(a=>a.tagName===i.tagName);if(y.length>1){const a=y.indexOf(i)+1;n.unshift(`${v}:nth-of-type(${a})`)}else n.unshift(v);i=m,r++}return n.join(" > ")||tag}const f="__guidesnap_overlay_host__";let l=null,E=null,b=null,g=null,h=null;const U=`
  :host { all: initial; }
  #gs-bar {
    position: fixed !important;
    bottom: 24px !important;
    right: 24px !important;
    z-index: 2147483647 !important;
    background: #1e1e2e !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 12px 16px !important;
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    font-size: 13px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,.35) !important;
    min-width: 200px !important;
    user-select: none !important;
  }
  #gs-dot {
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background: #ef4444 !important;
    flex-shrink: 0 !important;
    animation: gs-pulse 1.2s ease-in-out infinite !important;
  }
  #gs-dot.paused {
    background: #f59e0b !important;
    animation: none !important;
  }
  @keyframes gs-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
  }
  #gs-info { flex: 1 !important; }
  #gs-state { font-size: 11px !important; color: #FF6B35 !important; font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: .5px !important; }
  #gs-steps { font-size: 13px !important; color: #e0e0e0 !important; margin-top: 2px !important; }
  #gs-actions { display: flex !important; gap: 6px !important; }
  button {
    border: none !important;
    border-radius: 6px !important;
    padding: 5px 10px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: opacity .15s !important;
  }
  button:hover { opacity: .8 !important; }
  #gs-pause { background: rgba(255,255,255,.12) !important; color: #fff !important; }
  #gs-stop { background: #ef4444 !important; color: #fff !important; }
`;function L(){if(document.getElementById(f))return;const t=document.createElement("div");t.id=f,l=t.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=U,l.appendChild(e);const n=document.createElement("div");n.id="gs-bar",n.innerHTML=`
    <div id="gs-dot"></div>
    <div id="gs-info">
      <div id="gs-state">Recording</div>
      <div id="gs-steps">Step 0</div>
    </div>
    <div id="gs-actions">
      <button id="gs-pause">Pause</button>
      <button id="gs-stop">Stop</button>
    </div>
  `,l.appendChild(n),g=l.getElementById("gs-dot"),E=l.getElementById("gs-steps"),b=l.getElementById("gs-state"),h=l.getElementById("gs-pause"),h.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"PAUSE_RECORDING"})}),l.getElementById("gs-stop").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"STOP_RECORDING"})}),document.documentElement.appendChild(t)}function _(t,e){l&&(E&&(E.textContent=`${t} step${t!==1?"s":""} captured`),b&&(b.textContent=e==="paused"?"Paused":"Recording"),g&&(e==="paused"?g.classList.add("paused"):g.classList.remove("paused")),h&&(h.textContent=e==="paused"?"Resume":"Pause"))}function D(){const t=document.getElementById(f);t&&t.remove(),l=null,E=null,b=null,g=null,h=null}function H(){const t=document.getElementById(f);t&&(t.style.visibility="hidden")}function V(){const t=document.getElementById(f);t&&(t.style.visibility="visible")}if(window.__guidesnap_initialized__)throw new Error("GuideSnap content script already initialized");window.__guidesnap_initialized__=!0;let d=!1,s=!1,S=null,B=window.scrollY;const q=300,p=window.devicePixelRatio||1;console.log("[GuideSnap] Content script initialized");chrome.runtime.sendMessage({type:"GET_STATE"},t=>{console.log("[GuideSnap] Initial state:",t),(t==null?void 0:t.state)==="recording"?(d=!0,s=!1,L(),_(t.stepCount,"recording"),G()):(t==null?void 0:t.state)==="paused"&&(d=!0,s=!0,L(),_(t.stepCount,"paused"))});chrome.runtime.onMessage.addListener((t,e,n)=>{if(console.log("[GuideSnap] Content script received message:",t),t.type==="UPDATE_OVERLAY"){const{stepCount:i,state:r}=t.payload;if(r==="idle"){d=!1,s=!1,W(),D();return}r==="recording"&&!d?(console.log("[GuideSnap] Starting recording, attaching listeners"),d=!0,s=!1,L(),G()):r==="paused"?s=!0:r==="recording"&&s&&(s=!1),_(i,r),n({ok:!0})}if(t.type==="HIDE_OVERLAY"){H(),n({ok:!0});return}return t.type==="SHOW_OVERLAY"&&(V(),n({ok:!0})),!0});function P(t){var C,T,k,I,A,O,R;const e=t.getBoundingClientRect(),n=t.tagName.toLowerCase(),i=((C=t.getAttribute("aria-label"))==null?void 0:C.trim())||void 0,r=((T=t.getAttribute("placeholder"))==null?void 0:T.trim())||void 0,v=((k=t.getAttribute("name"))==null?void 0:k.trim())||void 0,m=((I=t.getAttribute("title"))==null?void 0:I.trim())||void 0,y=n==="input"&&t.type||void 0;let a;if(t.id){const o=document.querySelector(`label[for="${CSS.escape(t.id)}"]`);o&&(a=o.innerText.trim()||void 0)}if(!a){let o=t.parentElement;for(let u=0;u<3&&o;u++,o=o.parentElement)if(o.tagName.toLowerCase()==="label"){a=o.innerText.trim()||void 0;break}}if(!a){let o=t.previousElementSibling;for(let u=0;u<3&&o;u++,o=o.previousElementSibling){const c=(A=o.innerText)==null?void 0:A.trim();if(c&&c.length>0&&c.length<60){a=c;break}}}if(!a&&t.parentElement){let o=t.parentElement.previousElementSibling;for(let u=0;u<3&&o;u++,o=o.previousElementSibling){const c=(O=o.innerText)==null?void 0:O.trim();if(c&&c.length>0&&c.length<60){a=c;break}}}return{tag:n,text:((R=t.innerText)==null?void 0:R.trim().substring(0,80))??"",cssSelector:$(t),boundingBox:{x:e.left*p,y:e.top*p,width:e.width*p,height:e.height*p},ariaLabel:i,placeholder:r,name:v,inputType:y,title:m,labelText:a}}function x(t){chrome.runtime.sendMessage({type:"USER_EVENT",payload:t}).catch(()=>{})}const F=new Set(["a","button","input","select","textarea","label","li","summary","details","option"]),j=5;function X(t){let e=t;for(let n=0;n<j&&e;n++){if(F.has(e.tagName.toLowerCase())||e.hasAttribute("placeholder"))return e;e=e.parentElement}return t}function M(t){if(t.button!==0||(console.log("[GuideSnap] Mousedown detected, isRecording:",d,"isPaused:",s),!d||s))return;const e=t.target;if(!e||Z(e))return;const n=X(e),i={eventType:"click",element:P(n),clickPoint:{x:t.clientX*p,y:t.clientY*p},pageTitle:document.title,pageUrl:location.href};console.log("[GuideSnap] Sending mousedown event:",i),x(i)}function N(t){var r;if(!d||s)return;const e=t.target;if(!e||e.type==="password")return;const n=e.tagName.toLowerCase()==="select"?(((r=e.options[e.selectedIndex])==null?void 0:r.text)||e.value).substring(0,80):e.value.substring(0,80),i={eventType:"input",element:P(e),clickPoint:null,inputValue:n,pageTitle:document.title,pageUrl:location.href};x(i)}function w(){if(!d||s)return;const t={eventType:"navigate",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};x(t)}function z(){!d||s||Math.abs(window.scrollY-B)<q||(B=window.scrollY,S&&clearTimeout(S),S=setTimeout(()=>{const e={eventType:"scroll",element:null,clickPoint:null,pageTitle:document.title,pageUrl:location.href};x(e)},500))}function Z(t){return t.closest("#__guidesnap_overlay_host__")!==null}function G(){document.addEventListener("mousedown",M,!0),document.addEventListener("change",N,!0),window.addEventListener("popstate",w),window.addEventListener("hashchange",w),window.addEventListener("scroll",z,{passive:!0})}function W(){document.removeEventListener("mousedown",M,!0),document.removeEventListener("change",N,!0),window.removeEventListener("popstate",w),window.removeEventListener("hashchange",w),window.removeEventListener("scroll",z)}
})()
